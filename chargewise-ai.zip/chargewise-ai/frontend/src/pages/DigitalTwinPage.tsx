import React, { useState } from 'react';
import { useSimulation } from '../hooks/useSimulation';
import { ParkingLayout } from '../components/twin/ParkingLayout';
import { TwinCanvas } from '../components/twin/three/TwinCanvas';
import { VehicleDetail } from '../components/twin/VehicleDetail';
import { GridStatus } from '../components/twin/GridStatus';
import { PowerCapControl } from '../components/simulation/PowerCapControl';
import { SimulationControls } from '../components/simulation/SimulationControls';
import { PageId } from '../components/layout/Sidebar';
import { Zap } from 'lucide-react';

export interface DigitalTwinPageProps {
  simulation: ReturnType<typeof useSimulation>;
  onNavigate: (page: PageId) => void;
}

export const DigitalTwinPage: React.FC<DigitalTwinPageProps> = ({
  simulation,
  onNavigate,
}) => {
  const [viewMode, setViewMode] = useState<'3d' | '2d'>('3d');
  const currentInterval = simulation.currentInterval;
  const selectedSession = simulation.activeSessions.find(
    (s) => s.session_id === simulation.selectedSessionId
  );

  return (
    <div className="space-y-6">
      {/* Top telemetry and transformer control row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch">
        <div className="lg:col-span-8">
          <GridStatus
            totalPowerKw={currentInterval?.site_total_power_kw ?? 0}
            siteCapKw={simulation.siteCapKw}
            solarPowerKw={currentInterval?.solar_power_kw ?? 0}
            gridPowerKw={currentInterval?.grid_power_kw ?? 0}
            connectedCount={simulation.activeSessions.length}
            className="h-full"
          />
        </div>
        <div className="lg:col-span-4">
          <PowerCapControl
            currentCap={simulation.siteCapKw}
            onCapChange={simulation.setSiteCapKw}
            className="h-full flex flex-col justify-between"
          />
        </div>
      </div>

      {/* Playback & Step Controls */}
      <SimulationControls
        isRunning={simulation.isRunning}
        speed={simulation.speed}
        currentIntervalIndex={simulation.currentIntervalIndex}
        totalIntervals={simulation.totalIntervals}
        currentTime={simulation.currentTime}
        onTogglePlayPause={simulation.togglePlayPause}
        onStepForward={simulation.stepForward}
        onReset={simulation.reset}
        onSpeedChange={simulation.setSpeed}
      />

      {/* Main Digital Twin Grid: 3D/2D Facility + Vehicle Detail Side Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-8">
          {viewMode === '3d' ? (
            <TwinCanvas
              activeSessions={simulation.activeSessions}
              siteCapKw={simulation.siteCapKw}
              totalPowerKw={currentInterval?.site_total_power_kw ?? 0}
              solarPowerKw={currentInterval?.solar_power_kw ?? 0}
              selectedSessionId={simulation.selectedSessionId}
              onSelectSession={simulation.setSelectedSessionId}
              viewMode={viewMode}
              onViewModeChange={setViewMode}
              cutoffEvents={simulation.cutoffEvents}
            />
          ) : (
            <ParkingLayout
              activeSessions={simulation.activeSessions}
              siteCapKw={simulation.siteCapKw}
              totalPowerKw={currentInterval?.site_total_power_kw ?? 0}
              solarPowerKw={currentInterval?.solar_power_kw ?? 0}
              selectedSessionId={simulation.selectedSessionId}
              onSelectSession={simulation.setSelectedSessionId}
              viewMode={viewMode}
              onViewModeChange={setViewMode}
            />
          )}
        </div>

        <div className="lg:col-span-4">
          <VehicleDetail
            session={selectedSession}
            onEmergencyToggle={simulation.declareEmergency}
            onLeavingSoonToggle={simulation.declareLeavingSoon}
            onStopCharging={simulation.stopCharging}
            onStartCharging={simulation.startCharging}
            onOpenRescue={(sessionId) => {
              simulation.setSelectedSessionId(sessionId);
              onNavigate('rescue');
            }}
          />
        </div>
      </div>

      {/* Automatic Cutoff Telemetry & Safety Event Log */}
      <div className="p-4 rounded-xl bg-navy-850 border border-graphite-700/70 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-teal-500/10 text-teal-400 border border-teal-500/20">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                Automatic Cutoff & Safety Log
                <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-teal-500/10 text-teal-300 border border-teal-500/30">
                  {simulation.cutoffEvents.length} Events
                </span>
              </h4>
              <p className="text-[11px] text-gray-400">
                Real-time record of target energy reached, battery capacity protections, departure deadlines, and manual cutoffs.
              </p>
            </div>
          </div>
        </div>

        {simulation.cutoffEvents.length === 0 ? (
          <div className="p-4 rounded-lg bg-navy-900 border border-graphite-700/40 text-center text-xs text-gray-400 font-mono">
            No cutoff events triggered yet in this simulation window. Charging sessions are operating within limits.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5 max-h-64 overflow-y-auto pr-1">
            {simulation.cutoffEvents.slice(0, 9).map((evt, idx) => (
              <div
                key={`${evt.session_id}-${evt.reason}-${idx}`}
                className="p-2.5 rounded-lg bg-navy-900 border border-graphite-700/60 space-y-1.5 text-xs font-mono"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-teal-400" />
                    {evt.charger_id} ({evt.session_id})
                  </span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                      evt.reason === 'TARGET_REACHED'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : evt.reason === 'MANUAL_STOP'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : evt.reason === 'BATTERY_CAPACITY_LIMIT'
                        ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                        : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                    }`}
                  >
                    {evt.reason.replace('_', ' ')}
                  </span>
                </div>
                <p className="text-[11px] font-sans text-gray-300 leading-snug line-clamp-2">
                  {evt.message}
                </p>
                <div className="flex items-center justify-between text-[10px] text-gray-400 pt-1 border-t border-graphite-800">
                  <span>Delivered: {evt.final_energy_delivered_kwh.toFixed(1)} kWh</span>
                  <span>Power: 0.0 kW</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
