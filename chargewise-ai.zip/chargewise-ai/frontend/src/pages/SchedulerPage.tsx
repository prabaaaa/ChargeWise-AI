import React, { useState } from 'react';
import { useSimulation } from '../hooks/useSimulation';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { SessionTimeline } from '../components/charts/SessionTimeline';
import { formatPower, formatEnergy, formatTime } from '../utils/formatting';
import {
  Calendar,
  AlertTriangle,
  Zap,
  Clock,
  ShieldAlert,
  ArrowUpDown,
  CheckCircle2,
  ListOrdered,
} from 'lucide-react';
import { PageId } from '../components/layout/Sidebar';

export interface SchedulerPageProps {
  simulation: ReturnType<typeof useSimulation>;
  onNavigate: (page: PageId) => void;
}

export const SchedulerPage: React.FC<SchedulerPageProps> = ({
  simulation,
  onNavigate,
}) => {
  const [filter, setFilter] = useState<'all' | 'charging' | 'at_risk'>('all');

  const filteredSessions = simulation.activeSessions.filter((s) => {
    if (filter === 'charging') return s.allocated_power_kw > 0.1;
    if (filter === 'at_risk') return s.feasibility_status === 'at_risk' || s.feasibility_status === 'infeasible';
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header Info */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-2">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Calendar className="w-5 h-5 text-teal-400" />
            Dynamic Charging Scheduler
          </h2>
          <p className="text-xs text-gray-400 mt-1">
            Real-time deadline-driven power allocation, priority ranking, and feasibility validation across all 20 bays.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant={filter === 'all' ? 'primary' : 'secondary'}
            size="sm"
            onClick={() => setFilter('all')}
            className="text-xs"
          >
            All Active ({simulation.activeSessions.length})
          </Button>
          <Button
            variant={filter === 'charging' ? 'primary' : 'secondary'}
            size="sm"
            onClick={() => setFilter('charging')}
            className="text-xs"
          >
            Charging Now ({simulation.activeSessions.filter((s) => s.allocated_power_kw > 0.1).length})
          </Button>
          <Button
            variant={filter === 'at_risk' ? 'primary' : 'secondary'}
            size="sm"
            onClick={() => setFilter('at_risk')}
            className="text-xs"
          >
            At Risk ({simulation.activeSessions.filter((s) => s.feasibility_status !== 'feasible').length})
          </Button>
        </div>
      </div>

      {/* Gantt Schedule Timeline */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-bold flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-teal-400" />
              Vehicle Departure Gantt Timeline
            </span>
            <span className="text-xs font-mono font-normal text-teal-300">
              Current Simulation Time: {formatTime(simulation.currentTime)}
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <SessionTimeline
            sessions={simulation.allSessions}
            currentTime={simulation.currentTime}
            selectedSessionId={simulation.selectedSessionId}
            onSelectSession={simulation.setSelectedSessionId}
          />
        </CardContent>
      </Card>

      {/* Grid: Live Allocations Table + Scheduler Decision Log */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Allocations Table */}
        <div className="lg:col-span-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-3">
              <CardTitle className="text-sm font-bold flex items-center gap-2">
                <ListOrdered className="w-4 h-4 text-teal-400" />
                Active Allocations & Priority Ranking
              </CardTitle>
              <span className="text-xs font-mono text-gray-400">
                Total Allocated: {simulation.currentInterval?.site_total_power_kw ?? 0} / {simulation.siteCapKw} kW
              </span>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="text-[10px] text-gray-400 uppercase bg-navy-900 border-b border-graphite-700 font-mono">
                    <tr>
                      <th className="py-2.5 px-3">Rank / Charger</th>
                      <th className="py-2.5 px-3">Session</th>
                      <th className="py-2.5 px-3">Allocated</th>
                      <th className="py-2.5 px-3">Remaining Need</th>
                      <th className="py-2.5 px-3">Departure</th>
                      <th className="py-2.5 px-3">Status</th>
                      <th className="py-2.5 px-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-graphite-700/50 font-mono">
                    {filteredSessions.map((session, idx) => (
                      <tr
                        key={session.session_id}
                        className={`hover:bg-navy-800/80 transition-colors ${
                          session.is_emergency ? 'bg-red-950/20' : ''
                        }`}
                      >
                        <td className="py-2.5 px-3">
                          <span className="text-gray-400 font-normal mr-2">#{idx + 1}</span>
                          <span className="font-bold text-gray-200">{session.charger_id}</span>
                        </td>
                        <td className="py-2.5 px-3 text-gray-400">{session.session_id}</td>
                        <td className="py-2.5 px-3 font-bold text-teal-300">
                          {formatPower(session.allocated_power_kw)}
                        </td>
                        <td className="py-2.5 px-3 text-gray-300">
                          {formatEnergy(session.remaining_energy_kwh)}
                        </td>
                        <td className="py-2.5 px-3 text-gray-300">
                          {formatTime(session.departure_time)}
                        </td>
                        <td className="py-2.5 px-3 font-sans">
                          <div className="flex flex-col gap-1 items-start">
                            <Badge
                              variant={
                                session.is_emergency
                                  ? 'danger'
                                  : session.cutoff_status === 'TARGET REACHED'
                                  ? 'success'
                                  : session.cutoff_status === 'AUTO CUTOFF'
                                  ? 'warning'
                                  : session.cutoff_status === 'CHARGING'
                                  ? 'info'
                                  : 'neutral'
                              }
                              dot
                              className="text-[10px]"
                            >
                              {session.is_emergency
                                ? 'EMERGENCY'
                                : session.cutoff_status || session.feasibility_status.toUpperCase()}
                            </Badge>
                          </div>
                        </td>
                        <td className="py-2.5 px-3 text-right font-sans">
                          <div className="flex items-center justify-end gap-1.5">
                            <Button
                              variant={session.is_manually_stopped ? 'primary' : 'outline'}
                              size="sm"
                              onClick={() => session.is_manually_stopped
                                ? simulation.startCharging(session.session_id)
                                : simulation.stopCharging(session.session_id)
                              }
                              className={`text-[10px] h-6 px-2 ${
                                session.is_manually_stopped ? 'bg-teal-600 text-white' : 'text-amber-400 hover:bg-amber-950/40 border-amber-500/40'
                              }`}
                            >
                              {session.is_manually_stopped ? 'Resume' : 'Cutoff'}
                            </Button>
                            <Button
                              variant={session.is_emergency ? 'danger' : 'outline'}
                              size="sm"
                              onClick={() => simulation.declareEmergency(session.session_id)}
                              className="text-[10px] h-6 px-2"
                            >
                              {session.is_emergency ? 'Revert' : 'Emergency'}
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Scheduler Decision Log */}
        <div className="lg:col-span-4 space-y-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-bold flex items-center gap-2">
                <Zap className="w-4 h-4 text-teal-400" />
                Optimization Engine Log
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 font-mono text-xs">
              <div className="p-2.5 rounded bg-navy-900 border border-graphite-700 space-y-1">
                <span className="text-[10px] text-teal-400">STATUS: CONVERGED (0.012s)</span>
                <p className="text-[11px] text-gray-300">
                  Peak demand contained at {simulation.currentInterval?.site_total_power_kw ?? 0} kW (Cap: {simulation.siteCapKw} kW).
                </p>
              </div>

              <div className="p-2.5 rounded bg-navy-900 border border-graphite-700 space-y-1">
                <span className="text-[10px] text-amber-400">FAIRNESS & PRIORITY</span>
                <p className="text-[11px] text-gray-300">
                  Weighted earliest-deadline-first (EDF) with alpha-fair power distribution applied.
                </p>
              </div>

              <div className="p-2.5 rounded bg-navy-900 border border-graphite-700 space-y-1">
                <span className="text-[10px] text-blue-400">SOLAR CURVE SHIFT</span>
                <p className="text-[11px] text-gray-300">
                  Absorbed {simulation.currentInterval?.solar_power_kw ?? 0} kW solar output directly into EV batteries.
                </p>
              </div>

              <Button
                variant="tealOutline"
                size="sm"
                onClick={() => onNavigate('rescue')}
                className="w-full text-xs gap-1.5 mt-2 font-sans"
              >
                Inspect Rescue Hubs
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
