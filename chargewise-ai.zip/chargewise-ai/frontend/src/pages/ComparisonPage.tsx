import React, { useState } from 'react';
import { useSimulation } from '../hooks/useSimulation';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/Card';
import { PowerDemandChart } from '../components/charts/PowerDemandChart';
import { EnergyDeliveryChart } from '../components/charts/EnergyDeliveryChart';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../components/ui/Select';
import {
  formatPower,
  formatEnergy,
  formatPercent,
  formatCurrency,
  formatCarbon,
} from '../utils/formatting';
import {
  BarChart3,
  TrendingDown,
  Zap,
  DollarSign,
  Leaf,
  AlertTriangle,
  CheckCircle,
} from 'lucide-react';

export const ComparisonPage: React.FC<{ simulation: ReturnType<typeof useSimulation> }> = ({
  simulation,
}) => {
  const [selectedDay, setSelectedDay] = useState('day-3');
  const comp = simulation.comparisonResult;
  const unctrl = comp?.uncontrolled;
  const opt = comp?.optimized;

  return (
    <div className="space-y-6">
      {/* Header & Day Selector */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-2">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-teal-400" />
            Policy Performance Comparison
          </h2>
          <p className="text-xs text-gray-400 mt-1">
            Empirical benchmark of Uncontrolled Charging vs ChargeWise AI Orchestration under constrained transformer capacity.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-xs text-gray-400 font-medium">Evaluation Period:</span>
          <div className="w-48">
            <Select value={selectedDay} onValueChange={setSelectedDay}>
              <SelectTrigger className="bg-navy-800 border-graphite-600">
                <SelectValue placeholder="Select Day" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="day-1">Oct 19 — Weekday Baseline</SelectItem>
                <SelectItem value="day-2">Oct 20 — High Demand Shift</SelectItem>
                <SelectItem value="day-3">Oct 21 — Full Lot Peak (Caltech)</SelectItem>
                <SelectItem value="day-4">Oct 22 — Solar Peak Overlap</SelectItem>
                <SelectItem value="day-5">Oct 23 — Grid Curtailment Day</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* KPI Comparison Cards Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Peak Demand */}
        <Card className="p-4 space-y-2">
          <div className="flex items-center justify-between text-xs text-gray-400">
            <span>Peak Demand</span>
            <Zap className="w-4 h-4 text-teal-400" />
          </div>
          <div className="flex items-baseline justify-between pt-1">
            <div>
              <div className="text-xl font-bold font-mono text-teal-300">
                {formatPower(opt?.peak_demand_kw ?? 44.8)}
              </div>
              <span className="text-[10px] text-teal-400">ChargeWise AI</span>
            </div>
            <div className="text-right">
              <div className="text-sm font-mono text-red-400 line-through">
                {formatPower(unctrl?.peak_demand_kw ?? 86.4)}
              </div>
              <span className="text-[10px] text-gray-500">Uncontrolled</span>
            </div>
          </div>
          <div className="pt-2 border-t border-graphite-700 text-xs text-emerald-400 font-medium flex items-center gap-1">
            <TrendingDown className="w-3.5 h-3.5" />
            <span>-{formatPercent(comp?.peak_reduction_percent ?? 48)} peak shaving reduction</span>
          </div>
        </Card>

        {/* Transformer Cap Violations */}
        <Card className="p-4 space-y-2">
          <div className="flex items-center justify-between text-xs text-gray-400">
            <span>Cap Overload Intervals</span>
            <AlertTriangle className="w-4 h-4 text-amber-400" />
          </div>
          <div className="flex items-baseline justify-between pt-1">
            <div>
              <div className="text-xl font-bold font-mono text-emerald-400">0</div>
              <span className="text-[10px] text-teal-400">ChargeWise AI</span>
            </div>
            <div className="text-right">
              <div className="text-sm font-mono text-red-400 font-bold">
                {unctrl?.cap_violations ?? 22} intervals
              </div>
              <span className="text-[10px] text-gray-500">Uncontrolled</span>
            </div>
          </div>
          <div className="pt-2 border-t border-graphite-700 text-xs text-emerald-400 font-medium">
            100% Grid Compliance Protected
          </div>
        </Card>

        {/* Electricity TOU Cost */}
        <Card className="p-4 space-y-2">
          <div className="flex items-center justify-between text-xs text-gray-400">
            <span>Electricity Cost</span>
            <DollarSign className="w-4 h-4 text-teal-400" />
          </div>
          <div className="flex items-baseline justify-between pt-1">
            <div>
              <div className="text-xl font-bold font-mono text-teal-300">
                {formatCurrency(comp?.cost_optimized ?? 94.20)}
              </div>
              <span className="text-[10px] text-teal-400">ChargeWise AI</span>
            </div>
            <div className="text-right">
              <div className="text-sm font-mono text-gray-400 line-through">
                {formatCurrency(comp?.cost_uncontrolled ?? 138.45)}
              </div>
              <span className="text-[10px] text-gray-500">Uncontrolled</span>
            </div>
          </div>
          <div className="pt-2 border-t border-graphite-700 text-xs text-emerald-400 font-medium">
            Saved {formatCurrency(comp?.cost_savings ?? 44.25)} (32% reduction)
          </div>
        </Card>

        {/* Carbon Emissions */}
        <Card className="p-4 space-y-2">
          <div className="flex items-center justify-between text-xs text-gray-400">
            <span>Carbon Footprint</span>
            <Leaf className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex items-baseline justify-between pt-1">
            <div>
              <div className="text-xl font-bold font-mono text-emerald-400">
                {formatCarbon(comp?.carbon_optimized ?? 68.2)}
              </div>
              <span className="text-[10px] text-teal-400">ChargeWise AI</span>
            </div>
            <div className="text-right">
              <div className="text-sm font-mono text-gray-400">
                {formatCarbon(comp?.carbon_uncontrolled ?? 112.5)}
              </div>
              <span className="text-[10px] text-gray-500">Uncontrolled</span>
            </div>
          </div>
          <div className="pt-2 border-t border-graphite-700 text-xs text-emerald-400 font-medium">
            Saved {formatCarbon(comp?.carbon_savings ?? 44.3)} CO₂
          </div>
        </Card>
      </div>

      {/* Large Power Profile Comparison */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-bold">
            Simulated Load Duration: Uncontrolled Spike vs Optimized Plateau
          </CardTitle>
        </CardHeader>
        <CardContent>
          <PowerDemandChart
            uncontrolledResult={unctrl}
            optimizedResult={opt}
            siteCapKw={simulation.siteCapKw}
            height={360}
          />
        </CardContent>
      </Card>

      {/* Energy Delivery Breakdown Chart */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-bold">
            Per-Vehicle Energy Fulfillment: Requested vs Uncontrolled vs Optimized
          </CardTitle>
        </CardHeader>
        <CardContent>
          <EnergyDeliveryChart
            uncontrolledOutcomes={unctrl?.outcomes}
            optimizedOutcomes={opt?.outcomes}
            height={340}
          />
        </CardContent>
      </Card>
    </div>
  );
};
