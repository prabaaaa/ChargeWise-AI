import React, { useState } from 'react';
import { useSimulation } from '../hooks/useSimulation';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/Card';
import { SolarChart } from '../components/charts/SolarChart';
import { CostChart } from '../components/charts/CostChart';
import { Switch } from '../components/ui/Switch';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { formatEnergy, formatCarbon, formatCurrency } from '../utils/formatting';
import { Leaf, Sun, DollarSign, BatteryCharging, Zap } from 'lucide-react';

export const SustainabilityPage: React.FC<{ simulation: ReturnType<typeof useSimulation> }> = ({
  simulation,
}) => {
  const [solarEnabled, setSolarEnabled] = useState(true);
  const [curtailmentShift, setCurtailmentShift] = useState(true);

  const comp = simulation.comparisonResult;
  const sim = simulation.simulationResult;

  const totalDelivered = sim?.total_energy_delivered_kwh ?? 540;
  const solarGenerated = solarEnabled ? Math.round(totalDelivered * 0.42) : 0;
  const gridDrawn = totalDelivered - solarGenerated;

  return (
    <div className="space-y-6">
      {/* Top Banner with Toggle Controls */}
      <Card variant="glow" className="p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-teal-500/10 border border-teal-500/30 text-teal-400">
              <Leaf className="w-6 h-6 text-emerald-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Renewable Energy & Carbon Intelligence
                <Badge variant="success">Zero-Curtailment Mode</Badge>
              </h2>
              <p className="text-xs text-gray-400 mt-0.5">
                Aligns EV charging demand curves with rooftop solar PV generation and real-time marginal carbon intensity.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium text-gray-300">Rooftop Solar PV:</span>
              <Switch checked={solarEnabled} onCheckedChange={setSolarEnabled} />
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs font-medium text-gray-300">Clean Hour Shifting:</span>
              <Switch checked={curtailmentShift} onCheckedChange={setCurtailmentShift} />
            </div>
          </div>
        </div>

        {/* 3 Green Metrics */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-4 mt-4 border-t border-graphite-700/60 text-xs">
          <div className="p-3 rounded-lg bg-navy-900 border border-graphite-700">
            <span className="text-[10px] text-gray-400 uppercase">Solar Energy Absorbed</span>
            <div className="font-mono text-base font-bold text-amber-300 mt-0.5">
              {formatEnergy(solarGenerated)} ({solarEnabled ? '42%' : '0%'})
            </div>
          </div>

          <div className="p-3 rounded-lg bg-navy-900 border border-graphite-700">
            <span className="text-[10px] text-gray-400 uppercase">Grid Draw Avoided</span>
            <div className="font-mono text-base font-bold text-teal-300 mt-0.5">
              {formatEnergy(solarGenerated)}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-navy-900 border border-graphite-700">
            <span className="text-[10px] text-gray-400 uppercase">Carbon Emissions Avoided</span>
            <div className="font-mono text-base font-bold text-emerald-400 mt-0.5">
              {formatCarbon(comp?.carbon_savings ?? 44.3)}
            </div>
          </div>
        </div>
      </Card>

      {/* Solar Stacked Profile Chart */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-bold flex items-center gap-2">
            <Sun className="w-4 h-4 text-amber-400" />
            Solar Generation Absorption & Grid Import Breakdown
          </CardTitle>
        </CardHeader>
        <CardContent>
          <SolarChart
            intervals={simulation.simulationResult?.intervals ?? []}
            siteCapKw={simulation.siteCapKw}
            height={320}
          />
        </CardContent>
      </Card>

      {/* TOU Tariff & Cost Savings Chart */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-bold flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-teal-400" />
            Time-of-Use Electricity Tariff & Cost Minimization
          </CardTitle>
        </CardHeader>
        <CardContent>
          <CostChart
            uncontrolledResult={comp?.uncontrolled}
            optimizedResult={comp?.optimized}
            height={320}
          />
        </CardContent>
      </Card>
    </div>
  );
};
