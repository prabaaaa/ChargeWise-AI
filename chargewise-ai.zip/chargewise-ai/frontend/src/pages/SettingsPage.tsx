import React, { useState } from 'react';
import { useSimulation } from '../hooks/useSimulation';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { Slider } from '../components/ui/Slider';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../components/ui/Select';
import { Switch } from '../components/ui/Switch';
import { API_BASE_URL } from '../utils/constants';
import {
  Settings,
  Upload,
  Database,
  Server,
  RefreshCw,
  CheckCircle,
  Sliders,
  FileCheck,
} from 'lucide-react';

export const SettingsPage: React.FC<{ simulation: ReturnType<typeof useSimulation> }> = ({
  simulation,
}) => {
  const [site, setSite] = useState('caltech-jpl');
  const [fairnessMode, setFairnessMode] = useState(true);
  const [solverTimeout, setSolverTimeout] = useState([50]);
  const [notificationStatus, setNotificationStatus] = useState<string | null>(null);

  const handleResetDemo = () => {
    simulation.reset();
    simulation.setSiteCapKw(45);
    setNotificationStatus('Settings restored to Caltech-JPL Hackathon Demo Defaults!');
    setTimeout(() => setNotificationStatus(null), 4000);
  };

  return (
    <div className="space-y-6 max-w-5xl">
      {/* Title */}
      <div>
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Settings className="w-5 h-5 text-teal-400" />
          System Settings & Data Provenance
        </h2>
        <p className="text-xs text-gray-400 mt-1">
          Configure transformer physical parameters, simulation datasets, solver preferences, and live backend connection.
        </p>
      </div>

      {notificationStatus && (
        <div className="p-3 rounded-lg bg-teal-950/80 border border-teal-500/50 text-teal-300 text-xs flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-teal-400 shrink-0" />
          <span>{notificationStatus}</span>
        </div>
      )}

      {/* Grid: Dataset Configuration & Hardware Specs */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Dataset & Site Selector */}
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-bold flex items-center gap-2">
              <Database className="w-4 h-4 text-teal-400" />
              Dataset Benchmark & Site Selection
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-xs">
            <div className="space-y-1.5">
              <label className="text-gray-300 font-medium">Active Facility</label>
              <Select value={site} onValueChange={setSite}>
                <SelectTrigger className="bg-navy-900 border-graphite-600">
                  <SelectValue placeholder="Select site" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="caltech-jpl">Caltech-JPL Research Lot (20 Bays)</SelectItem>
                  <SelectItem value="office-park">Silicon Valley Tech Campus (30 Bays)</SelectItem>
                  <SelectItem value="municipal-depot">Municipal EV Fleet Depot (15 Bays)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Upload dataset file mock */}
            <div className="space-y-1.5">
              <label className="text-gray-300 font-medium">Custom EV Session Data (.csv, .json)</label>
              <div className="border-2 border-dashed border-graphite-600 hover:border-teal-500/50 rounded-xl p-4 text-center cursor-pointer transition-colors bg-navy-900/40">
                <Upload className="w-6 h-6 text-gray-400 mx-auto mb-1" />
                <p className="text-[11px] text-gray-300 font-medium">Click to upload Caltech ACN format session traces</p>
                <p className="text-[10px] text-gray-500 mt-0.5">Supports arrivals, target kWh, departure timestamps</p>
              </div>
            </div>

            <div className="p-3 rounded-lg bg-navy-900 border border-graphite-700 space-y-1 text-gray-400 text-[11px]">
              <div className="flex items-center gap-1.5 text-gray-300 font-medium">
                <FileCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Pre-loaded Benchmark: ACN-Data (Caltech)</span>
              </div>
              <p>20 concurrent sessions, 15-minute intervals, verified transformer constraints.</p>
            </div>
          </CardContent>
        </Card>

        {/* Transformer & Electrical Limits */}
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-bold flex items-center gap-2">
              <Sliders className="w-4 h-4 text-teal-400" />
              Electrical Substation Parameters
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-xs">
            <div className="space-y-1.5">
              <div className="flex justify-between">
                <label className="text-gray-300 font-medium">Transformer Cap Limit</label>
                <span className="font-mono text-teal-300 font-bold">{simulation.siteCapKw} kW</span>
              </div>
              <Slider
                value={[simulation.siteCapKw]}
                min={10}
                max={120}
                step={5}
                onValueChange={(val) => simulation.setSiteCapKw(val[0])}
              />
              <div className="flex justify-between text-[10px] text-gray-500">
                <span>10 kW (Tight)</span>
                <span>45 kW (Default)</span>
                <span>120 kW (Unconstrained)</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <div>
                <span className="text-gray-300 font-medium block">Proportional Alpha-Fairness</span>
                <span className="text-[10px] text-gray-500">Prevent starve of low-urgency vehicles</span>
              </div>
              <Switch checked={fairnessMode} onCheckedChange={setFairnessMode} />
            </div>

            <div className="space-y-1.5 pt-2">
              <div className="flex justify-between">
                <label className="text-gray-300 font-medium">Solver Time Budget</label>
                <span className="font-mono text-teal-300">{solverTimeout[0]} ms</span>
              </div>
              <Slider
                value={solverTimeout}
                min={10}
                max={200}
                step={10}
                onValueChange={setSolverTimeout}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Backend API Connection & Diagnostics */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-bold flex items-center gap-2">
            <Server className="w-4 h-4 text-teal-400" />
            Backend API Configuration & Demo Standalone Mode
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-xs">
          <div className="flex flex-wrap items-center justify-between gap-4 p-3 rounded-lg bg-navy-900 border border-graphite-700">
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-gray-200">FastAPI Backend Endpoint:</span>
                <span className="font-mono text-teal-300">{API_BASE_URL}</span>
              </div>
              <p className="text-[11px] text-gray-400 mt-0.5">
                Frontend features zero-dependency browser simulation fallback for offline hackathon demonstrations.
              </p>
            </div>

            <Badge variant="success" dot>
              BROWSER SIMULATION ENGINE READY
            </Badge>
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" size="sm" onClick={handleResetDemo} className="gap-1.5">
              <RefreshCw className="w-3.5 h-3.5" />
              Reset All to Demo Defaults
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
