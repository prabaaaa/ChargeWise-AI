import React from 'react';
import { useSimulation } from '../hooks/useSimulation';
import { KpiCard } from '../components/ui/KpiCard';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/Card';
import { PowerDemandChart } from '../components/charts/PowerDemandChart';
import { SimulationControls } from '../components/simulation/SimulationControls';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { formatPower, formatEnergy, formatCurrency, formatCarbon, formatPercent } from '../utils/formatting';
import {
  Zap,
  TrendingDown,
  BatteryCharging,
  Car,
  DollarSign,
  Leaf,
  Database,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';
import { PageId } from '../components/layout/Sidebar';

export interface OverviewPageProps {
  simulation: ReturnType<typeof useSimulation>;
  onNavigate: (page: PageId) => void;
}

export const OverviewPage: React.FC<OverviewPageProps> = ({ simulation, onNavigate }) => {
  const comp = simulation.comparisonResult;
  const sim = simulation.simulationResult;

  const peakDemand = sim?.peak_demand_kw ?? 44.8;
  const peakReduction = comp?.peak_reduction_percent ?? 42.5;
  const energyDelivered = sim?.total_energy_delivered_kwh ?? 540.2;
  const vehiclesServed = sim?.sessions_count ?? 20;
  const costSavings = comp?.cost_savings ?? 44.25;
  const carbonSavings = comp?.carbon_savings ?? 44.3;

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-navy-800 via-graphite-800 to-navy-800 p-6 border border-graphite-600/50 shadow-xl">
        <div className="relative z-10 flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1.5 max-w-2xl">
            <div className="flex items-center gap-2">
              <Badge variant="info">AI-POWERED LOAD MANAGEMENT</Badge>
              <span className="text-xs text-gray-400 font-mono">CALTECH JPL PILOT</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              Autonomous EV Charging & Grid Orchestration
            </h1>
            <p className="text-xs sm:text-sm text-gray-300 leading-relaxed">
              ChargeWise AI prevents substation transformer overload through real-time dynamic load balancing, peak shaving, and algorithmic charging rescue dispatch.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <Button variant="primary" onClick={() => onNavigate('digital-twin')} className="gap-2">
              Launch Live Digital Twin
              <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
        <div className="absolute -right-12 -top-12 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* 6 KPI Cards in a row */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        <KpiCard
          label="Peak Demand"
          value={formatPower(peakDemand).replace(' kW', '')}
          unit="kW"
          icon={Zap}
          iconColor="text-teal-400"
          comparisonValue={`${formatPower(comp?.uncontrolled.peak_demand_kw ?? 86.4)}`}
          comparisonLabel="Uncontrolled"
        />

        <KpiCard
          label="Peak Reduction"
          value={`-${formatPercent(peakReduction)}`}
          icon={TrendingDown}
          iconColor="text-emerald-400"
          trend={{
            value: 'Grid Safe',
            direction: 'down',
          }}
        />

        <KpiCard
          label="Energy Delivered"
          value={formatEnergy(energyDelivered).replace(' kWh', '')}
          unit="kWh"
          icon={BatteryCharging}
          iconColor="text-teal-300"
          trend={{
            value: '98.5%',
            direction: 'up',
            label: 'served',
          }}
        />

        <KpiCard
          label="EVs Served"
          value={vehiclesServed}
          unit="vehicles"
          icon={Car}
          iconColor="text-electric-green"
          trend={{
            value: '100%',
            direction: 'neutral',
            label: 'scheduled',
          }}
        />

        <KpiCard
          label="Cost Savings"
          value={formatCurrency(costSavings)}
          icon={DollarSign}
          iconColor="text-teal-400"
          comparisonValue={formatCurrency(comp?.cost_uncontrolled ?? 138.45)}
          comparisonLabel="Base"
        />

        <KpiCard
          label="Carbon Offset"
          value={formatCarbon(carbonSavings).replace(' kg CO₂', '')}
          unit="kg CO₂"
          icon={Leaf}
          iconColor="text-emerald-400"
          trend={{
            value: '-39%',
            direction: 'down',
            label: 'emissions',
          }}
        />
      </div>

      {/* Simulation Quick Controls */}
      <SimulationControls
        isRunning={simulation.isRunning}
        speed={simulation.speed}
        currentIntervalIndex={simulation.currentIntervalIndex}
        totalIntervals={simulation.totalIntervals}
        currentTime={simulation.currentTime}
        onTogglePlayPause={simulation.togglePlayPause}
        onStepForward={simulation.stepForward}
        onReset={simulation.reset}
        onSpeedChange={simulation.setSpeed}
      />

      {/* Full-width Power Demand Chart */}
      <Card variant="default">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div>
            <CardTitle className="text-base font-bold">
              Site Power Demand Profile vs Grid Transformer Cap
            </CardTitle>
            <p className="text-xs text-gray-400">
              Comparing uncontrolled maximum draw (red area) against ChargeWise AI intelligent load shaving (teal area).
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onNavigate('comparison')}
            className="text-xs gap-1 hidden sm:flex"
          >
            Detailed Comparison
            <ArrowRight className="w-3.5 h-3.5" />
          </Button>
        </CardHeader>
        <CardContent>
          <PowerDemandChart
            uncontrolledResult={comp?.uncontrolled}
            optimizedResult={comp?.optimized}
            siteCapKw={simulation.siteCapKw}
            currentIntervalTimestamp={simulation.currentTime}
            height={320}
          />
        </CardContent>
      </Card>

      {/* Lower Row: Active Sessions Summary + Dataset Provenance */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Active Charging Sessions Snapshot */}
        <div className="lg:col-span-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-bold flex items-center gap-2">
                <Car className="w-4 h-4 text-teal-400" />
                Active Sessions at Current Interval ({simulation.activeSessions.length} Vehicles)
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onNavigate('scheduler')}
                className="text-xs text-teal-300"
              >
                View Full Scheduler →
              </Button>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="text-[10px] text-gray-400 uppercase bg-navy-900 border-b border-graphite-700 font-mono">
                    <tr>
                      <th className="py-2 px-3">Charger</th>
                      <th className="py-2 px-3">Session</th>
                      <th className="py-2 px-3">Allocated Power</th>
                      <th className="py-2 px-3">Delivered / Target</th>
                      <th className="py-2 px-3">Priority</th>
                      <th className="py-2 px-3">Feasibility</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-graphite-700/50 font-mono">
                    {simulation.activeSessions.slice(0, 6).map((session) => (
                      <tr key={session.session_id} className="hover:bg-navy-800/60">
                        <td className="py-2 px-3 font-bold text-gray-200">{session.charger_id}</td>
                        <td className="py-2 px-3 text-gray-400">{session.session_id}</td>
                        <td className="py-2 px-3 text-teal-300 font-semibold">{formatPower(session.allocated_power_kw)}</td>
                        <td className="py-2 px-3 text-gray-300">
                          {formatEnergy(session.energy_delivered_kwh)} / {formatEnergy(session.energy_requested_kwh)}
                        </td>
                        <td className="py-2 px-3 text-gray-200">{session.priority_score}/100</td>
                        <td className="py-2 px-3 font-sans">
                          <Badge
                            variant={session.feasibility_status === 'feasible' ? 'success' : 'warning'}
                            dot
                            className="text-[10px]"
                          >
                            {session.feasibility_status.toUpperCase()}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Dataset Provenance Card */}
        <div className="lg:col-span-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-bold flex items-center gap-2">
                <Database className="w-4 h-4 text-teal-400" />
                Dataset & Provenance
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-xs text-gray-300">
              <div className="p-3 rounded-lg bg-navy-900/80 border border-graphite-700 space-y-1.5">
                <div className="text-[10px] text-gray-400 uppercase font-mono">Source Benchmark</div>
                <div className="font-semibold text-white">Caltech ACN EV Research Lot</div>
                <p className="text-[11px] text-gray-400">
                  Caltech JPL charging records, 15-minute intervals, Level 2 and DC fast charging sessions.
                </p>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-gray-400">
                  <span>Transformer Cap:</span>
                  <span className="font-mono text-teal-300 font-bold">{simulation.siteCapKw} kW</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Optimization Engine:</span>
                  <span className="font-mono text-gray-200">Convex QP / Deadline Priority</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Solar Integration:</span>
                  <span className="font-mono text-emerald-400">Active (34 kWp PV)</span>
                </div>
              </div>

              <Button
                variant="outline"
                size="sm"
                onClick={() => onNavigate('settings')}
                className="w-full text-xs mt-2"
              >
                Configure Settings & Datasets
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
