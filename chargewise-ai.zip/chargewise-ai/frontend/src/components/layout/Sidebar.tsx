import React from 'react';
import {
  LayoutDashboard,
  Monitor,
  Calendar,
  BarChart3,
  LifeBuoy,
  Leaf,
  Settings,
  Zap,
  X,
} from 'lucide-react';
import { cn } from '../../utils/formatting';

export type PageId =
  | 'overview'
  | 'digital-twin'
  | 'scheduler'
  | 'comparison'
  | 'rescue'
  | 'sustainability'
  | 'settings';

interface SidebarProps {
  currentPage: PageId;
  onPageChange: (page: PageId) => void;
  isOpen: boolean;
  onClose: () => void;
  className?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPage,
  onPageChange,
  isOpen,
  onClose,
  className,
}) => {
  const navItems: { id: PageId; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'digital-twin', label: 'Live Digital Twin', icon: Monitor },
    { id: 'scheduler', label: 'Charging Scheduler', icon: Calendar },
    { id: 'comparison', label: 'Policy Comparison', icon: BarChart3 },
    { id: 'rescue', label: 'Charging Rescue', icon: LifeBuoy },
    { id: 'sustainability', label: 'Energy & Sustainability', icon: Leaf },
    { id: 'settings', label: 'Data & Settings', icon: Settings },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-navy-900/80 backdrop-blur-sm lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar container */}
      <aside
        className={cn(
          'fixed inset-y-0 left-0 z-50 flex w-64 flex-col bg-navy-800 border-r border-graphite-700/60 transition-transform duration-200 ease-in-out lg:static lg:translate-x-0',
          isOpen ? 'translate-x-0' : '-translate-x-full',
          className
        )}
      >
        {/* Brand Header */}
        <div className="flex h-16 items-center justify-between px-5 border-b border-graphite-700/60">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-teal-400 to-teal-600 shadow-lg shadow-teal-500/20 text-navy-900">
              <Zap className="h-5 w-5 fill-current" />
            </div>
            <div>
              <span className="font-bold tracking-tight text-white text-base">ChargeWise</span>
              <span className="text-teal-400 font-bold ml-1 text-base">AI</span>
              <span className="block text-[10px] text-gray-400 font-mono tracking-wider -mt-0.5">
                ORCHESTRATION OS
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-graphite-700 lg:hidden"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation list */}
        <nav className="flex-1 space-y-1.5 px-3 py-4 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onPageChange(item.id);
                  onClose();
                }}
                className={cn(
                  'flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 text-xs font-medium transition-all group relative select-none',
                  isActive
                    ? 'bg-teal-500/15 text-teal-300 font-semibold shadow-inner'
                    : 'text-gray-400 hover:bg-graphite-700/50 hover:text-gray-200'
                )}
              >
                {isActive && (
                  <div className="absolute left-0 top-1.5 bottom-1.5 w-1 rounded-r-full bg-teal-400 shadow-[0_0_8px_#2dd4bf]" />
                )}
                <Icon
                  className={cn(
                    'h-4 w-4 shrink-0 transition-colors',
                    isActive ? 'text-teal-400' : 'text-gray-400 group-hover:text-gray-200'
                  )}
                />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Bottom Facility Status badge */}
        <div className="p-4 border-t border-graphite-700/60 bg-navy-900/40">
          <div className="rounded-xl p-3 bg-graphite-800/80 border border-graphite-700 text-xs space-y-1.5">
            <div className="flex items-center justify-between text-gray-400 text-[10px] uppercase font-mono">
              <span>Site Status</span>
              <span className="flex items-center gap-1 text-emerald-400 font-semibold">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                OPTIMIZED
              </span>
            </div>
            <div className="text-gray-200 font-semibold">Caltech-JPL Main Lot</div>
            <div className="text-[10px] text-gray-400 font-mono">20 Connected / 45 kW Cap</div>
          </div>
        </div>
      </aside>
    </>
  );
};
