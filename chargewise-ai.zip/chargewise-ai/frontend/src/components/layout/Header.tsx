import React from 'react';
import { Menu, Play, Pause, RotateCcw, Zap, Car, Clock } from 'lucide-react';
import { Button } from '../ui/Button';
import { formatTime } from '../../utils/formatting';
import { cn } from '../../utils/formatting';

export interface HeaderProps {
  onToggleSidebar: () => void;
  isRunning: boolean;
  onTogglePlayPause: () => void;
  onReset: () => void;
  currentTime: string;
  connectedCount: number;
  currentPowerKw: number;
  siteCapKw: number;
  policy: string;
}

export const Header: React.FC<HeaderProps> = ({
  onToggleSidebar,
  isRunning,
  onTogglePlayPause,
  onReset,
  currentTime,
  connectedCount,
  currentPowerKw,
  siteCapKw,
  policy,
}) => {
  const isCapExceeded = currentPowerKw > siteCapKw;

  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-graphite-700/60 bg-navy-800/90 px-4 sm:px-6 backdrop-blur-md">
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleSidebar}
          className="p-2 rounded-lg text-gray-400 hover:text-white hover:bg-graphite-700 lg:hidden"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="hidden sm:flex items-center gap-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-gray-400">Policy:</span>
          <span className="px-2 py-0.5 rounded text-xs font-semibold font-mono bg-teal-500/15 text-teal-300 border border-teal-500/30">
            {policy === 'optimized' ? 'ChargeWise Smart (Peak Shaved)' : 'Uncontrolled (Max Draw)'}
          </span>
        </div>
      </div>

      {/* Header Quick Stats & Controls */}
      <div className="flex items-center gap-3 sm:gap-4">
        {/* Simulation Time */}
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-navy-900 border border-graphite-700 font-mono text-xs text-gray-200">
          <Clock className="w-3.5 h-3.5 text-teal-400" />
          <span className="font-bold">{formatTime(currentTime)}</span>
        </div>

        {/* Connected vehicles */}
        <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-navy-900 border border-graphite-700 text-xs text-gray-200 font-mono">
          <Car className="w-3.5 h-3.5 text-teal-300" />
          <span>{connectedCount} EVs</span>
        </div>

        {/* Site Power Usage */}
        <div
          className={cn(
            'flex items-center gap-1.5 px-2.5 py-1 rounded-lg border font-mono text-xs',
            isCapExceeded
              ? 'bg-red-950/80 text-red-300 border-red-500/50 animate-pulse'
              : 'bg-navy-900 text-gray-200 border-graphite-700'
          )}
        >
          <Zap className={cn('w-3.5 h-3.5', isCapExceeded ? 'text-red-400' : 'text-teal-400')} />
          <span className="font-bold">{currentPowerKw.toFixed(1)}</span>
          <span className="text-[10px] text-gray-400">/ {siteCapKw} kW</span>
        </div>

        {/* Quick Play/Pause & Reset */}
        <div className="flex items-center gap-1">
          <Button
            variant={isRunning ? 'secondary' : 'primary'}
            size="sm"
            onClick={onTogglePlayPause}
            className="h-8 px-2.5 text-xs gap-1"
          >
            {isRunning ? (
              <>
                <Pause className="w-3.5 h-3.5 fill-current" />
                <span className="hidden sm:inline">Pause</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                <span className="hidden sm:inline">Run</span>
              </>
            )}
          </Button>

          <Button
            variant="ghost"
            size="icon"
            onClick={onReset}
            className="h-8 w-8 text-gray-400 hover:text-white"
            title="Reset"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>
    </header>
  );
};
