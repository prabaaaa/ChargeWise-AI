import React from 'react';
import { cn } from '../../utils/formatting';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost' | 'outline' | 'tealOutline';
  size?: 'sm' | 'md' | 'lg' | 'icon';
  isLoading?: boolean;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'primary', size = 'md', isLoading = false, disabled, children, ...props }, ref) => {
    const baseStyles = 'inline-flex items-center justify-center font-medium rounded-lg transition-all focus:outline-none focus:ring-2 focus:ring-teal-400 focus:ring-offset-2 focus:ring-offset-navy-900 disabled:opacity-50 disabled:pointer-events-none active:scale-[0.98] select-none';

    const variants = {
      primary: 'bg-teal-500 hover:bg-teal-400 text-navy-900 font-semibold shadow-md shadow-teal-500/20 hover:shadow-teal-500/30',
      secondary: 'bg-graphite-700 hover:bg-graphite-600 text-gray-100 border border-graphite-600/70 shadow-sm',
      danger: 'bg-red-alert/90 hover:bg-red-alert text-white shadow-md shadow-red-500/20',
      ghost: 'bg-transparent hover:bg-graphite-700/60 text-gray-300 hover:text-white',
      outline: 'bg-transparent border border-graphite-600 text-gray-300 hover:bg-graphite-800 hover:text-white',
      tealOutline: 'bg-teal-500/10 border border-teal-500/40 text-teal-300 hover:bg-teal-500/20 hover:border-teal-400',
    };

    const sizes = {
      sm: 'text-xs px-3 py-1.5 h-8 gap-1.5',
      md: 'text-sm px-4 py-2 h-10 gap-2',
      lg: 'text-base px-5 py-2.5 h-12 gap-2.5',
      icon: 'h-9 w-9 p-0 flex items-center justify-center',
    };

    return (
      <button
        ref={ref}
        disabled={disabled || isLoading}
        className={cn(baseStyles, variants[variant], sizes[size], className)}
        {...props}
      >
        {isLoading ? (
          <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-current" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
          </svg>
        ) : null}
        {children}
      </button>
    );
  }
);

Button.displayName = 'Button';
