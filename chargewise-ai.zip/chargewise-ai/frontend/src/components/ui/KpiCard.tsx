import React from 'react';
import { Card } from './Card';
import { cn } from '../../utils/formatting';
import { LucideIcon } from 'lucide-react';

export interface KpiCardProps {
  label: string;
  value: string | number;
  unit?: string;
  icon?: LucideIcon;
  iconColor?: string;
  trend?: {
    value: string | number;
    direction: 'up' | 'down' | 'neutral';
    label?: string;
  };
  comparisonValue?: string;
  comparisonLabel?: string;
  className?: string;
}

export const KpiCard: React.FC<KpiCardProps> = ({
  label,
  value,
  unit,
  icon: Icon,
  iconColor = 'text-teal-400',
  trend,
  comparisonValue,
  comparisonLabel,
  className,
}) => {
  return (
    <Card className={cn('relative overflow-hidden group hover:border-teal-500/40 transition-all p-4.5', className)}>
      <div className="flex items-start justify-between">
        <div className="space-y-1">
          <p className="text-xs font-medium text-gray-400 uppercase tracking-wider">{label}</p>
          <div className="flex items-baseline gap-1.5 pt-1">
            <span className="text-2xl lg:text-3xl font-bold tracking-tight text-white font-mono">{value}</span>
            {unit && <span className="text-xs text-gray-400 font-medium">{unit}</span>}
          </div>
        </div>

        {Icon && (
          <div className={cn('p-2.5 rounded-xl bg-navy-800/80 border border-graphite-600/40 shadow-inner group-hover:scale-110 transition-transform duration-200', iconColor)}>
            <Icon className="w-5 h-5" />
          </div>
        )}
      </div>

      {(trend || comparisonValue) && (
        <div className="mt-3 pt-2.5 border-t border-graphite-700/40 flex items-center justify-between text-xs">
          {trend && (
            <div className="flex items-center gap-1">
              <span
                className={cn(
                  'font-medium inline-flex items-center',
                  trend.direction === 'up' && 'text-emerald-400',
                  trend.direction === 'down' && 'text-teal-300',
                  trend.direction === 'neutral' && 'text-gray-400'
                )}
              >
                {trend.direction === 'up' ? '↑ ' : trend.direction === 'down' ? '↓ ' : ''}
                {trend.value}
              </span>
              {trend.label && <span className="text-gray-400">{trend.label}</span>}
            </div>
          )}

          {comparisonValue && (
            <div className="text-gray-400 ml-auto">
              {comparisonLabel && <span>{comparisonLabel}: </span>}
              <span className="text-gray-300 font-medium">{comparisonValue}</span>
            </div>
          )}
        </div>
      )}
    </Card>
  );
};
