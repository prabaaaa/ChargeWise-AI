import React from 'react';
import { RescueStation } from '../../api/types';
import { Card } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import {
  Navigation,
  Zap,
  Clock,
  MapPin,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
} from 'lucide-react';
import { cn } from '../../utils/formatting';

export interface StationCardProps {
  station: RescueStation;
  isSelected?: boolean;
  onSelect?: () => void;
  className?: string;
}

export const StationCard: React.FC<StationCardProps> = ({
  station,
  isSelected,
  onSelect,
  className,
}) => {
  const isAvailable = station.availability.toLowerCase().includes('available');
  const isReachable = station.is_reachable !== false;

  const handleDirections = (e: React.MouseEvent) => {
    e.stopPropagation();
    const url = `https://www.google.com/maps/dir/?api=1&destination=${station.latitude},${station.longitude}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <Card
      onClick={onSelect}
      className={cn(
        'cursor-pointer transition-all hover:border-teal-500/50 p-4 space-y-3',
        isSelected && 'border-teal-400 bg-navy-800/90 ring-1 ring-teal-400/50 shadow-teal-500/10 shadow-lg',
        !isReachable && 'border-red-500/40 bg-red-950/20',
        className
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <h4 className="text-sm font-bold text-white tracking-wide">{station.name}</h4>
            {station.is_demo && (
              <Badge variant="neutral" className="text-[9px] py-0 px-1.5">
                DEMO
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-2 text-xs text-gray-400">
            <span className="flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-teal-400" />
              {station.distance_km} km away
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-gray-400" />
              ~{station.driving_time_minutes ?? 5} min drive
            </span>
          </div>
        </div>

        <Badge
          variant={isAvailable ? 'success' : 'warning'}
          dot
          className="text-[10px] shrink-0"
        >
          {station.availability}
        </Badge>
      </div>

      {/* Charging Specs */}
      <div className="flex flex-wrap items-center gap-1.5 pt-1">
        <span className="px-2 py-0.5 rounded text-xs font-mono font-bold bg-teal-500/15 text-teal-300 border border-teal-500/30 flex items-center gap-1">
          <Zap className="w-3 h-3" />
          {station.max_power_kw} kW Max
        </span>

        {station.connectors.map((c) => (
          <span
            key={c}
            className="px-2 py-0.5 rounded text-[11px] font-mono bg-graphite-700 text-gray-300 border border-graphite-600"
          >
            {c}
          </span>
        ))}
      </div>

      {/* Recommendation reason */}
      <div className="p-2 rounded bg-navy-900/80 border border-graphite-700/70 text-xs text-gray-300 flex items-start gap-2">
        <CheckCircle2 className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
        <p className="leading-snug">{station.recommendation_reason}</p>
      </div>

      {!isReachable && (
        <div className="flex items-center gap-1.5 text-xs text-red-400 bg-red-950/60 p-2 rounded border border-red-500/40">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span>Warning: EV remaining battery may be critically low to guarantee reaching this station.</span>
        </div>
      )}

      {/* Actions */}
      <div className="flex items-center justify-between pt-1">
        <span className="text-[10px] text-gray-400">
          Transit energy: ~{station.energy_needed_to_reach_kwh?.toFixed(2) ?? '0.50'} kWh
        </span>

        <Button
          variant="tealOutline"
          size="sm"
          onClick={handleDirections}
          className="text-xs h-7 px-2.5 gap-1"
        >
          <Navigation className="w-3 h-3" />
          Get Directions
          <ExternalLink className="w-3 h-3 opacity-60" />
        </Button>
      </div>
    </Card>
  );
};
