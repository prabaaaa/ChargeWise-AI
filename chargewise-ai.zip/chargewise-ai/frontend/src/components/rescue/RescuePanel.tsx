import React, { useState, useEffect } from 'react';
import { RescueStation, ActiveSession, ChargingSession } from '../../api/types';
import { StationCard } from './StationCard';
import { RescueMap } from './RescueMap';
import { Card, CardHeader, CardTitle, CardContent } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../ui/Select';
import { LifeBuoy, AlertTriangle, ShieldCheck, MapPin, Zap } from 'lucide-react';
import { apiClient } from '../../api/client';
import { formatEnergy } from '../../utils/formatting';

export interface RescuePanelProps {
  sessions: ChargingSession[];
  activeSessions: ActiveSession[];
  initialSelectedSessionId?: string | null;
  className?: string;
}

export const RescuePanel: React.FC<RescuePanelProps> = ({
  sessions,
  activeSessions,
  initialSelectedSessionId,
  className,
}) => {
  const [selectedSessionId, setSelectedSessionId] = useState<string>(
    initialSelectedSessionId || sessions[0]?.session_id || 'cs-101'
  );
  const [stations, setStations] = useState<RescueStation[]>([]);
  const [selectedStationId, setSelectedStationId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (initialSelectedSessionId) {
      setSelectedSessionId(initialSelectedSessionId);
    }
  }, [initialSelectedSessionId]);

  useEffect(() => {
    let isMounted = true;
    setLoading(true);
    apiClient.getRescueStations(selectedSessionId).then((res) => {
      if (isMounted) {
        setStations(res);
        if (res.length > 0 && !selectedStationId) {
          setSelectedStationId(res[0].station_id);
        }
        setLoading(false);
      }
    });
    return () => {
      isMounted = false;
    };
  }, [selectedSessionId]);

  const currentSessionMeta = sessions.find((s) => s.session_id === selectedSessionId);
  const currentActive = activeSessions.find((s) => s.session_id === selectedSessionId);

  const reqEnergy = currentSessionMeta?.requested_energy_kwh ?? 25;
  const delEnergy = currentActive?.energy_delivered_kwh ?? 12;
  const shortfall = Math.max(0, reqEnergy - delEnergy);
  const estimatedSoc = currentActive?.initial_soc_percent ?? 25;

  return (
    <div className={`space-y-6 ${className || ''}`}>
      {/* Top Banner / Session Selector */}
      <Card variant="glow" className="p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-teal-500/10 border border-teal-500/30 text-teal-400">
              <LifeBuoy className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                Charging Rescue Network
                <Badge variant="info">Smart Off-site Dispatch</Badge>
              </h3>
              <p className="text-xs text-gray-400 mt-0.5">
                Automatically resolves site capacity shortfalls by guiding vehicles to nearby high-power DC fast hubs.
              </p>
            </div>
          </div>

          {/* EV Session Selector */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-400 font-medium">Select Vehicle:</span>
            <div className="w-56">
              <Select value={selectedSessionId} onValueChange={setSelectedSessionId}>
                <SelectTrigger className="bg-navy-900 border-graphite-600">
                  <SelectValue placeholder="Select Vehicle" />
                </SelectTrigger>
                <SelectContent>
                  {sessions.map((s) => (
                    <SelectItem key={s.session_id} value={s.session_id}>
                      {s.charger_id} ({s.session_id}) — {s.requested_energy_kwh} kWh
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Selected Vehicle Status Alert */}
        <div className="mt-4 pt-4 border-t border-graphite-700/60 grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3 rounded-lg bg-navy-900 border border-graphite-700">
            <span className="text-[10px] text-gray-400 uppercase">Target Shortfall</span>
            <div className="font-mono text-base font-bold text-amber-300 mt-0.5">
              {shortfall > 0 ? formatEnergy(shortfall) : '0.0 kWh (Fully Met)'}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-navy-900 border border-graphite-700">
            <span className="text-[10px] text-gray-400 uppercase">Connector Standard</span>
            <div className="font-mono text-base font-bold text-teal-300 mt-0.5">
              {currentSessionMeta?.connector_type || 'CCS / NACS'}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-navy-900 border border-graphite-700">
            <span className="text-[10px] text-gray-400 uppercase">Battery Level (SOC)</span>
            <div className="font-mono text-base font-bold text-white mt-0.5">
              {estimatedSoc}%
            </div>
          </div>

          <div className="p-3 rounded-lg bg-navy-900 border border-graphite-700">
            <span className="text-[10px] text-gray-400 uppercase">Reachability Status</span>
            <div className="font-mono text-base font-bold text-emerald-400 mt-0.5 flex items-center gap-1">
              <ShieldCheck className="w-4 h-4" />
              Reachable (4.2x Reserve)
            </div>
          </div>
        </div>
      </Card>

      {/* Main Grid: Interactive Map + Recommended Station Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Map */}
        <div className="lg:col-span-7 space-y-3">
          <div className="flex items-center justify-between text-xs text-gray-400">
            <span className="font-medium text-gray-300 flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-teal-400" />
              Regional DC Fast Charging Hubs (5 km Radius)
            </span>
            <span>{stations.length} locations available</span>
          </div>
          <RescueMap
            stations={stations}
            selectedStationId={selectedStationId}
            onSelectStation={setSelectedStationId}
            className="h-[480px] w-full"
          />
        </div>

        {/* Right: Station Recommendations List */}
        <div className="lg:col-span-5 space-y-3">
          <div className="text-xs text-gray-400 font-medium">
            Recommended Stations ranked by transit time & charger capability:
          </div>
          <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
            {stations.map((st) => (
              <StationCard
                key={st.station_id}
                station={st}
                isSelected={selectedStationId === st.station_id}
                onSelect={() => setSelectedStationId(st.station_id)}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
