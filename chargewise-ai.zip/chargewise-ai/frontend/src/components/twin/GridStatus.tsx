import React from 'react';
import { Zap, Sun, Car, Activity } from 'lucide-react';
import { Progress } from '../ui/Progress';
import { cn } from '../../utils/formatting';

export interface GridStatusProps {
  totalPowerKw: number;
  siteCapKw: number;
  solarPowerKw: number;
  gridPowerKw: number;
  connectedCount: number;
  className?: string;
}

export const GridStatus: React.FC<GridStatusProps> = ({
  totalPowerKw,
  siteCapKw,
  solarPowerKw,
  gridPowerKw,
  connectedCount,
  className,
}) => {
  const utilization = siteCapKw > 0 ? (totalPowerKw / siteCapKw) * 100 : 0;
  const isOverCap = totalPowerKw > siteCapKw;
  const isNearCap = utilization > 85;

  return (
    <div className={cn('p-4 rounded-xl bg-graphite-800/90 border border-graphite-600/50 shadow-md space-y-3', className)}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-teal-500/10 border border-teal-500/30 text-teal-400">
            <Activity className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-semibold text-gray-200 uppercase tracking-wider">Grid & Transformer Status</h4>
            <p className="text-[10px] text-gray-400">Real-time telemetry</p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <span
            className={cn(
              'px-2 py-0.5 rounded text-[10px] font-mono font-semibold uppercase tracking-wider border',
              isOverCap
                ? 'bg-red-950/80 text-red-300 border-red-500/50 animate-pulse'
                : isNearCap
                ? 'bg-amber-950/80 text-amber-300 border-amber-500/50'
                : 'bg-emerald-950/80 text-emerald-300 border-emerald-500/50'
            )}
          >
            {isOverCap ? 'CAP EXCEEDED' : isNearCap ? 'HEAVY LOAD' : 'OPTIMAL'}
          </span>
        </div>
      </div>

      {/* 4 Metrics in a row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-xs">
        <div className="p-2.5 rounded-lg bg-navy-900/80 border border-graphite-700">
          <div className="flex items-center gap-1.5 text-gray-400 text-[10px] mb-1">
            <Zap className="w-3 h-3 text-teal-400" />
            <span>Site Load</span>
          </div>
          <div className="font-mono text-base font-bold text-white">
            {totalPowerKw.toFixed(1)} <span className="text-[10px] font-normal text-gray-400">/ {siteCapKw} kW</span>
          </div>
        </div>

        <div className="p-2.5 rounded-lg bg-navy-900/80 border border-graphite-700">
          <div className="flex items-center gap-1.5 text-gray-400 text-[10px] mb-1">
            <Sun className="w-3 h-3 text-amber-400" />
            <span>Solar Generation</span>
          </div>
          <div className="font-mono text-base font-bold text-amber-300">
            {solarPowerKw.toFixed(1)} <span className="text-[10px] font-normal text-gray-400">kW</span>
          </div>
        </div>

        <div className="p-2.5 rounded-lg bg-navy-900/80 border border-graphite-700">
          <div className="flex items-center gap-1.5 text-gray-400 text-[10px] mb-1">
            <Zap className="w-3 h-3 text-blue-400" />
            <span>Grid Import</span>
          </div>
          <div className="font-mono text-base font-bold text-blue-300">
            {gridPowerKw.toFixed(1)} <span className="text-[10px] font-normal text-gray-400">kW</span>
          </div>
        </div>

        <div className="p-2.5 rounded-lg bg-navy-900/80 border border-graphite-700">
          <div className="flex items-center gap-1.5 text-gray-400 text-[10px] mb-1">
            <Car className="w-3 h-3 text-teal-300" />
            <span>Connected EVs</span>
          </div>
          <div className="font-mono text-base font-bold text-teal-300">
            {connectedCount} <span className="text-[10px] font-normal text-gray-400">vehicles</span>
          </div>
        </div>
      </div>

      {/* Utilization Bar */}
      <div className="space-y-1 pt-1">
        <div className="flex justify-between text-[11px] text-gray-400">
          <span>Capacity Utilization</span>
          <span className="font-mono font-bold text-gray-200">{Math.round(utilization)}%</span>
        </div>
        <Progress
          value={Math.min(100, utilization)}
          indicatorClassName={cn(
            isOverCap ? 'bg-red-alert' : isNearCap ? 'bg-amber-warn' : 'bg-teal-400'
          )}
        />
      </div>
    </div>
  );
};
