import React from 'react';
import { ActiveSession } from '../../api/types';
import { Card, CardHeader, CardTitle, CardContent } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Progress } from '../ui/Progress';
import { formatTime, formatEnergy, formatPower } from '../../utils/formatting';
import {
  Car,
  Clock,
  Zap,
  BatteryCharging,
  AlertTriangle,
  LifeBuoy,
  TimerReset,
  ShieldAlert,
  PowerOff,
  Play,
  CheckCircle2,
  ShieldCheck,
} from 'lucide-react';

export interface VehicleDetailProps {
  session?: ActiveSession | null;
  onEmergencyToggle?: (sessionId: string) => void;
  onLeavingSoonToggle?: (sessionId: string) => void;
  onOpenRescue?: (sessionId: string) => void;
  onStopCharging?: (sessionId: string) => void;
  onStartCharging?: (sessionId: string) => void;
  className?: string;
}

export const VehicleDetail: React.FC<VehicleDetailProps> = ({
  session,
  onEmergencyToggle,
  onLeavingSoonToggle,
  onOpenRescue,
  onStopCharging,
  onStartCharging,
  className,
}) => {
  if (!session) {
    return (
      <Card className={className}>
        <div className="flex flex-col items-center justify-center p-8 text-center text-gray-400 space-y-2">
          <Car className="w-10 h-10 stroke-[1.5] text-gray-500" />
          <h4 className="text-sm font-medium text-gray-300">No Vehicle Selected</h4>
          <p className="text-xs text-gray-500">
            Click on any charging bay in the digital twin layout to inspect vehicle telemetry and scheduling controls.
          </p>
        </div>
      </Card>
    );
  }

  const reqEnergy = session.energy_requested_kwh || 25;
  const delEnergy = session.energy_delivered_kwh || 0;
  const energyPercent = Math.min(100, Math.round((delEnergy / reqEnergy) * 100));

  const initialSoc = session.initial_soc_percent ?? 25;
  const batteryCap = session.battery_capacity_kwh ?? 70;
  // Estimated current SOC: initial + (delivered / batteryCap) * 100
  const estimatedSoc = Math.min(100, Math.round(initialSoc + (delEnergy / batteryCap) * 100));

  const isEmergency = session.is_emergency;
  const isAtRisk = session.feasibility_status === 'at_risk' || session.feasibility_status === 'infeasible';

  return (
    <Card className={className} variant={isEmergency ? 'danger' : 'glow'}>
      <CardHeader className="pb-3 border-b border-graphite-700/60">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-teal-500/10 border border-teal-500/30 text-teal-400">
              <Car className="w-5 h-5" />
            </div>
            <div>
              <CardTitle className="text-base font-bold text-white">
                {session.charger_id}
                <span className="text-xs font-mono font-normal text-gray-400 ml-2">
                  ({session.session_id})
                </span>
              </CardTitle>
              <div className="flex items-center gap-2 mt-0.5">
                <Badge variant={session.feasibility_status === 'feasible' ? 'success' : 'warning'} dot>
                  {session.feasibility_status.replace('_', ' ').toUpperCase()}
                </Badge>
                <span className="text-[10px] text-gray-400 bg-navy-900 px-1.5 py-0.5 rounded border border-graphite-700">
                  {session.departure_source}
                </span>
              </div>
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs text-gray-400">Priority</span>
            <div className="text-lg font-mono font-bold text-teal-300">
              {session.priority_score ?? 50}/100
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4 pt-4">
        {/* State of Charge (SOC) */}
        <div className="space-y-1.5 p-3 rounded-lg bg-navy-900/80 border border-graphite-700">
          <div className="flex justify-between text-xs">
            <span className="text-gray-400 flex items-center gap-1.5">
              <BatteryCharging className="w-3.5 h-3.5 text-teal-400" />
              Battery Level (SOC)
            </span>
            <span className="font-mono font-bold text-white">{estimatedSoc}%</span>
          </div>
          <Progress value={estimatedSoc} indicatorClassName="bg-teal-400" />
          <div className="flex justify-between text-[10px] text-gray-500 pt-0.5">
            <span>Started: {initialSoc}%</span>
            <span>Capacity: {batteryCap} kWh</span>
            <span>Target: 80%+</span>
          </div>
        </div>

        {/* Energy delivery numbers */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="p-2.5 rounded-lg bg-navy-900/60 border border-graphite-700">
            <span className="text-[10px] text-gray-400">Energy Delivered</span>
            <div className="font-mono text-sm font-bold text-teal-300 mt-0.5">
              {formatEnergy(delEnergy)}
            </div>
            <span className="text-[10px] text-gray-500">Target: {formatEnergy(reqEnergy)} ({energyPercent}%)</span>
          </div>

          <div className="p-2.5 rounded-lg bg-navy-900/60 border border-graphite-700">
            <span className="text-[10px] text-gray-400">Current Power</span>
            <div className="font-mono text-sm font-bold text-electric-green mt-0.5">
              {formatPower(session.allocated_power_kw)}
            </div>
            <span className="text-[10px] text-gray-500">Active allocation</span>
          </div>
        </div>

        {/* Automatic Cutoff Status Banner */}
        {session.cutoff_status === 'TARGET REACHED' && (
          <div className="p-3 rounded-lg bg-emerald-950/40 border border-emerald-500/50 flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div className="space-y-0.5 text-xs">
              <span className="font-semibold text-emerald-200">Automatic Cutoff Active: Target Reached</span>
              <p className="text-[11px] text-emerald-300/80 leading-relaxed">
                Vehicle reached requested target energy ({formatEnergy(session.energy_delivered_kwh)}). Power output cut to 0.0 kW to protect battery longevity and capacity reallocated.
              </p>
            </div>
          </div>
        )}

        {(session.is_manually_stopped || session.cutoff_status === 'AUTO CUTOFF') && (
          <div className="p-3 rounded-lg bg-amber-950/40 border border-amber-500/50 flex items-start gap-2.5">
            <PowerOff className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div className="space-y-0.5 text-xs">
              <span className="font-semibold text-amber-200">Charging Cutoff: Manual Stop</span>
              <p className="text-[11px] text-amber-300/80 leading-relaxed">
                Operator manually stopped charging for this session. Power allocation held at 0.0 kW. Click Start Charging to re-enable.
              </p>
            </div>
          </div>
        )}

        {/* Timings */}
        <div className="p-2.5 rounded-lg bg-navy-900/60 border border-graphite-700 flex justify-between text-xs font-mono">
          <div>
            <span className="text-[10px] text-gray-400 block font-sans">Arrival</span>
            <span className="text-gray-200">{formatTime(session.arrival_time)}</span>
          </div>
          <div className="text-right">
            <span className="text-[10px] text-gray-400 block font-sans">Scheduled Departure</span>
            <span className="text-teal-300 font-bold">{formatTime(session.departure_time)}</span>
          </div>
        </div>

        {/* Operator Interactive Actions */}
        <div className="space-y-2 pt-2 border-t border-graphite-700">
          {/* Manual Cutoff Override: Start / Stop Charging */}
          <Button
            variant={session.is_manually_stopped ? 'primary' : 'danger'}
            size="sm"
            onClick={() => session.is_manually_stopped
              ? onStartCharging?.(session.session_id)
              : onStopCharging?.(session.session_id)
            }
            className="w-full text-xs gap-1.5"
          >
            {session.is_manually_stopped ? (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                Start / Resume Charging
              </>
            ) : (
              <>
                <PowerOff className="w-3.5 h-3.5" />
                Stop Charging (Manual Cutoff)
              </>
            )}
          </Button>

          <div className="grid grid-cols-2 gap-2">
            <Button
              variant={isEmergency ? 'danger' : 'outline'}
              size="sm"
              onClick={() => onEmergencyToggle?.(session.session_id)}
              className="text-xs gap-1.5"
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              {isEmergency ? 'Cancel Emergency' : 'Emergency Priority'}
            </Button>

            <Button
              variant="secondary"
              size="sm"
              onClick={() => onLeavingSoonToggle?.(session.session_id)}
              className="text-xs gap-1.5"
            >
              <TimerReset className="w-3.5 h-3.5" />
              Leaving Soon
            </Button>
          </div>

          {isAtRisk && (
            <Button
              variant="tealOutline"
              size="sm"
              onClick={() => onOpenRescue?.(session.session_id)}
              className="w-full text-xs gap-1.5"
            >
              <LifeBuoy className="w-3.5 h-3.5" />
              View DC Fast Charging Rescue Options
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
