import React from 'react';
import { Zap, AlertOctagon } from 'lucide-react';
import { Slider } from '../ui/Slider';
import { Button } from '../ui/Button';
import { SITE_CAP_PRESETS } from '../../utils/constants';
import { cn } from '../../utils/formatting';

export interface PowerCapControlProps {
  currentCap: number;
  onCapChange: (newCap: number) => void;
  className?: string;
  compact?: boolean;
}

export const PowerCapControl: React.FC<PowerCapControlProps> = ({
  currentCap,
  onCapChange,
  className,
  compact = false,
}) => {
  const handleStressTest = () => {
    // Drop cap to 50% of current or minimum 15 kW
    const stressedCap = Math.max(15, Math.round(currentCap * 0.5));
    onCapChange(stressedCap);
  };

  return (
    <div className={cn('p-4 rounded-xl bg-graphite-800/90 border border-graphite-600/50 shadow-md', className)}>
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-teal-500/10 border border-teal-500/30 text-teal-400">
            <Zap className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-semibold text-gray-200 uppercase tracking-wider">Site Power Cap</h4>
            <p className="text-[10px] text-gray-400">Transformer limit constraint</p>
          </div>
        </div>

        <div className="flex items-baseline gap-1 bg-navy-900 px-2.5 py-1 rounded-md border border-graphite-700 font-mono">
          <span className="text-base font-bold text-teal-300">{currentCap}</span>
          <span className="text-[10px] text-gray-400 font-medium">kW</span>
        </div>
      </div>

      <div className="py-2">
        <Slider
          value={[currentCap]}
          min={5}
          max={100}
          step={1}
          onValueChange={(val) => onCapChange(val[0])}
        />
        <div className="flex justify-between text-[10px] text-gray-500 mt-1">
          <span>5 kW</span>
          <span>50 kW</span>
          <span>100 kW</span>
        </div>
      </div>

      {!compact && (
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-graphite-700/50 mt-1">
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] text-gray-400 font-medium mr-1">Presets:</span>
            {SITE_CAP_PRESETS.map((preset) => (
              <button
                key={preset}
                onClick={() => onCapChange(preset)}
                className={cn(
                  'px-2 py-0.5 rounded text-xs font-mono transition-colors border',
                  currentCap === preset
                    ? 'bg-teal-500 text-navy-900 border-teal-400 font-semibold shadow-sm'
                    : 'bg-graphite-700 text-gray-300 border-graphite-600/80 hover:bg-graphite-600 hover:text-white'
                )}
              >
                {preset}k
              </button>
            ))}
          </div>

          <Button
            variant="danger"
            size="sm"
            onClick={handleStressTest}
            className="text-[11px] h-7 px-2.5 gap-1 shadow-red-500/10"
            title="Halve site capacity to trigger real-time curtailment & rescue"
          >
            <AlertOctagon className="w-3.5 h-3.5" />
            -50% Stress Test
          </Button>
        </div>
      )}
    </div>
  );
};
