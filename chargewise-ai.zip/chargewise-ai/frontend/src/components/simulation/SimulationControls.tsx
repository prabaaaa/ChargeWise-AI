import React from 'react';
import { Play, Pause, StepForward, RotateCcw, FastForward } from 'lucide-react';
import { Button } from '../ui/Button';
import { Progress } from '../ui/Progress';
import { TimeDisplay } from './TimeDisplay';
import { SIMULATION_SPEEDS } from '../../utils/constants';
import { cn } from '../../utils/formatting';

export interface SimulationControlsProps {
  isRunning: boolean;
  speed: number;
  currentIntervalIndex: number;
  totalIntervals: number;
  currentTime: string;
  onTogglePlayPause: () => void;
  onStepForward: () => void;
  onReset: () => void;
  onSpeedChange: (speed: number) => void;
  onIntervalChange?: (index: number) => void;
  className?: string;
}

export const SimulationControls: React.FC<SimulationControlsProps> = ({
  isRunning,
  speed,
  currentIntervalIndex,
  totalIntervals,
  currentTime,
  onTogglePlayPause,
  onStepForward,
  onReset,
  onSpeedChange,
  className,
}) => {
  const progressPercent = totalIntervals > 0 ? ((currentIntervalIndex + 1) / totalIntervals) * 100 : 0;

  return (
    <div className={cn('p-4 rounded-xl bg-graphite-800/90 border border-graphite-600/50 shadow-md space-y-3', className)}>
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Playback action buttons */}
        <div className="flex items-center gap-2">
          <Button
            variant={isRunning ? 'secondary' : 'primary'}
            size="sm"
            onClick={onTogglePlayPause}
            className="w-24 gap-1.5"
          >
            {isRunning ? (
              <>
                <Pause className="w-4 h-4 fill-current" />
                Pause
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                Play
              </>
            )}
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={onStepForward}
            title="Advance 15-minute interval"
            disabled={isRunning}
            className="gap-1 text-xs"
          >
            <StepForward className="w-3.5 h-3.5" />
            +15m
          </Button>

          <Button
            variant="ghost"
            size="icon"
            onClick={onReset}
            title="Reset simulation to beginning"
            className="text-gray-400 hover:text-white"
          >
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>

        {/* Speed selector */}
        <div className="flex items-center gap-1.5 bg-navy-900/90 p-1 rounded-lg border border-graphite-700">
          <FastForward className="w-3.5 h-3.5 text-gray-400 ml-1 mr-0.5" />
          {SIMULATION_SPEEDS.map((s) => (
            <button
              key={s}
              onClick={() => onSpeedChange(s)}
              className={cn(
                'px-2 py-0.5 rounded text-xs font-mono transition-colors',
                speed === s
                  ? 'bg-teal-500 text-navy-900 font-bold'
                  : 'text-gray-400 hover:text-gray-200'
              )}
            >
              {s}x
            </button>
          ))}
        </div>

        {/* Time display */}
        <TimeDisplay
          isoString={currentTime}
          intervalIndex={currentIntervalIndex}
          totalIntervals={totalIntervals}
        />
      </div>

      {/* Progress track */}
      <div className="space-y-1">
        <Progress value={progressPercent} className="h-1.5" />
        <div className="flex justify-between text-[10px] text-gray-400">
          <span>06:00 (Start)</span>
          <span>12:00 (Solar Peak)</span>
          <span>22:00 (End)</span>
        </div>
      </div>
    </div>
  );
};
