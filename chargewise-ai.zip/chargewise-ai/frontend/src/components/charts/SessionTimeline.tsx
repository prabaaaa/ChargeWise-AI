import React from 'react';
import { ChargingSession } from '../../api/types';
import { formatTime } from '../../utils/formatting';
import { cn } from '../../utils/formatting';

export interface SessionTimelineProps {
  sessions: ChargingSession[];
  currentTime?: string;
  onSelectSession?: (sessionId: string) => void;
  selectedSessionId?: string | null;
}

export const SessionTimeline: React.FC<SessionTimelineProps> = ({
  sessions,
  currentTime,
  onSelectSession,
  selectedSessionId,
}) => {
  const startHour = 6;
  const endHour = 22;
  const totalHours = endHour - startHour;

  // Convert time to percentage from 06:00 to 22:00
  const getPercent = (timeStr: string) => {
    try {
      const parts = timeStr.includes('T') ? timeStr.split('T')[1].split(':') : timeStr.split(':');
      const hour = parseInt(parts[0], 10);
      const min = parseInt(parts[1], 10);
      const frac = hour + min / 60;
      const clamped = Math.max(startHour, Math.min(endHour, frac));
      return ((clamped - startHour) / totalHours) * 100;
    } catch {
      return 0;
    }
  };

  const currentPercent = currentTime ? getPercent(currentTime) : null;

  return (
    <div className="w-full space-y-4">
      {/* Time header axis */}
      <div className="relative h-6 border-b border-graphite-700 text-[10px] text-gray-400 font-mono select-none">
        {Array.from({ length: 9 }).map((_, idx) => {
          const hour = startHour + idx * 2;
          const leftPct = ((hour - startHour) / totalHours) * 100;
          return (
            <div
              key={hour}
              className="absolute -translate-x-1/2 flex flex-col items-center"
              style={{ left: `${leftPct}%` }}
            >
              <span>{String(hour).padStart(2, '0')}:00</span>
              <div className="w-px h-1.5 bg-graphite-600 mt-0.5" />
            </div>
          );
        })}
      </div>

      {/* Sessions schedule bars */}
      <div className="space-y-2 max-h-[360px] overflow-y-auto pr-1">
        {sessions.map((session) => {
          const leftPct = getPercent(session.arrival_time);
          const rightPct = getPercent(session.departure_time);
          const widthPct = Math.max(2, rightPct - leftPct);
          const isSelected = selectedSessionId === session.session_id;

          return (
            <div
              key={session.session_id}
              onClick={() => onSelectSession?.(session.session_id)}
              className={cn(
                'group relative flex items-center h-8 rounded-lg cursor-pointer px-2 transition-all',
                isSelected ? 'bg-teal-500/15 border border-teal-500/40' : 'bg-navy-800/60 hover:bg-navy-800 border border-graphite-700/50'
              )}
            >
              <div className="w-20 shrink-0 flex items-center gap-1.5">
                <span className="text-xs font-mono font-medium text-gray-200">
                  {session.charger_id}
                </span>
                <span className="text-[10px] text-gray-400">
                  {session.requested_energy_kwh}k
                </span>
              </div>

              <div className="relative flex-1 h-5 rounded bg-graphite-700/40 overflow-hidden">
                {/* Visual block representing parking / charging duration */}
                <div
                  className={cn(
                    'absolute h-full rounded transition-all',
                    isSelected
                      ? 'bg-gradient-to-r from-teal-400 to-teal-500 shadow-md shadow-teal-500/30'
                      : 'bg-gradient-to-r from-teal-600/70 to-teal-500/70 group-hover:from-teal-500 group-hover:to-teal-400'
                  )}
                  style={{ left: `${leftPct}%`, width: `${widthPct}%` }}
                >
                  <div className="h-full flex items-center justify-between px-1.5 text-[9px] font-mono text-navy-900 font-semibold truncate">
                    <span>{formatTime(session.arrival_time)}</span>
                    <span>{formatTime(session.departure_time)}</span>
                  </div>
                </div>

                {/* Current simulation time vertical marker */}
                {currentPercent !== null && (
                  <div
                    className="absolute top-0 bottom-0 w-0.5 bg-electric-green z-10 pointer-events-none"
                    style={{ left: `${currentPercent}%` }}
                  />
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
