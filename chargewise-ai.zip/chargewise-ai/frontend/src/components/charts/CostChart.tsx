import React from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
} from 'recharts';
import { DEFAULT_TARIFF_PROFILE } from '../../utils/constants';
import { SimulationResult } from '../../api/types';

export interface CostChartProps {
  uncontrolledResult?: SimulationResult | null;
  optimizedResult?: SimulationResult | null;
  height?: number;
}

export const CostChart: React.FC<CostChartProps> = ({
  uncontrolledResult,
  optimizedResult,
  height = 340,
}) => {
  // Aggregate hourly energy * tariff rate for both policies
  const hours = Array.from({ length: 16 }, (_, i) => i + 6); // 6:00 to 21:00

  const hourlyData = hours.map((hour) => {
    const tariff = DEFAULT_TARIFF_PROFILE[hour] || 0.20;
    const hourPrefix = `${String(hour).padStart(2, '0')}:`;

    // Filter intervals belonging to this hour
    const unctrlIntervals = uncontrolledResult?.intervals.filter((int) =>
      int.timestamp.includes(`T${hourPrefix}`)
    ) || [];
    const optIntervals = optimizedResult?.intervals.filter((int) =>
      int.timestamp.includes(`T${hourPrefix}`)
    ) || [];

    // Sum kW * 0.25h * tariff
    const unctrlKwh = unctrlIntervals.reduce((sum, int) => sum + int.grid_power_kw * 0.25, 0);
    const optKwh = optIntervals.reduce((sum, int) => sum + int.grid_power_kw * 0.25, 0);

    const costUnctrl = unctrlKwh * tariff;
    const costOpt = optKwh * tariff;

    return {
      hour: `${hour}:00`,
      tariff: `$${tariff.toFixed(2)}/kWh`,
      isPeakTOU: hour >= 16 && hour <= 20,
      uncontrolledCost: Math.round(costUnctrl * 100) / 100,
      optimizedCost: Math.round(costOpt * 100) / 100,
      savings: Math.max(0, Math.round((costUnctrl - costOpt) * 100) / 100),
    };
  });

  return (
    <div className="w-full h-full min-h-[300px]">
      <ResponsiveContainer width="100%" height={height}>
        <BarChart
          data={hourlyData}
          margin={{ top: 15, right: 15, left: -10, bottom: 0 }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#243049" vertical={false} />
          <XAxis
            dataKey="hour"
            stroke="#9ca3af"
            fontSize={11}
            tickLine={false}
          />
          <YAxis
            stroke="#9ca3af"
            fontSize={11}
            tickLine={false}
            unit=" $"
          />
          <Tooltip
            contentStyle={{
              backgroundColor: '#111827',
              borderColor: '#374151',
              borderRadius: '0.5rem',
              boxShadow: '0 10px 25px -5px rgba(0,0,0,0.5)',
              fontSize: '12px',
            }}
            formatter={(value: any, name: string) => {
              const formatted = `$${Number(value).toFixed(2)}`;
              if (name === 'uncontrolledCost') return [formatted, 'Uncontrolled Cost'];
              if (name === 'optimizedCost') return [formatted, 'Optimized Cost'];
              return [formatted, name];
            }}
            labelFormatter={(label) => `${label} (TOU Rate Applied)`}
          />
          <Legend
            verticalAlign="top"
            height={36}
            iconType="circle"
            formatter={(value) => {
              if (value === 'uncontrolledCost') return <span className="text-xs text-rose-400">Uncontrolled Cost ($)</span>;
              if (value === 'optimizedCost') return <span className="text-xs text-teal-400 font-semibold">ChargeWise AI Cost ($)</span>;
              return <span className="text-xs text-gray-300">{value}</span>;
            }}
          />
          <Bar dataKey="uncontrolledCost" fill="#ef4444" radius={[4, 4, 0, 0]} />
          <Bar dataKey="optimizedCost" fill="#14b8a6" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};
