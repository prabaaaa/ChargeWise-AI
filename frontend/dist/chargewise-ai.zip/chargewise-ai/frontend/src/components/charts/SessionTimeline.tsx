import React from 'react';
import { ChargingSession } from '../../api/types';
import { formatTime } from '../../utils/formatting';
import { cn } from '../../utils/formatting';

export interface SessionTimelineProps {
  sessions: ChargingSession[];
  currentTime?: string;
  onSelectSession?: (sessionId: string) => void;
  selectedSessionId?: string | null;
}

export const SessionTimeline: React.FC<SessionTimelineProps> = ({
  sessions,
  currentTime,
  onSelectSession,
  selectedSessionId,
}) => {
  const startHour = 6;
  const endHour = 22;
  const totalHours = endHour - startHour;

  // Convert time to percentage from 06:00 to 22:00
  const getPercent = (timeStr: string) => {
    try {
      const parts = timeStr.includes('T') ? timeStr.split('T')[1].split(':') : timeStr.split(':');
      const hour = parseInt(parts[0], 10);
      const min = parseInt(parts[1], 10);
      const frac = hour + min / 60;
      const clamped = Math.max(startHour, Math.min(endHour, frac));
      return ((clamped - startHour) / totalHours) * 100;
    } catch {
      return 0;
    }
  };

  const currentPercent = currentTime ? getPercent(currentTime) : null;

  return (
    <div className="w-full space-y-4">
      {/* Time header axis */}
      <div className="relative h-6 border-b border-[#253441] text-[10px] text-[#91A5B3] font-mono select-none">
        {Array.from({ length: 9 }).map((_, idx) => {
          const hour = startHour + idx * 2;
          const leftPct = ((hour - startHour) / totalHours) * 100;
          return (
            <div
              key={hour}
              className="absolute -translate-x-1/2 flex flex-col items-center"
              style={{ left: `${leftPct}%` }}
            >
              <span>{String(hour).padStart(2, '0')}:00</span>
              <div className="w-px h-1.5 bg-[#253441] mt-0.5" />
            </div>
          );
        })}
      </div>

      {/* Sessions schedule bars */}
      <div className="space-y-2 max-h-[360px] overflow-y-auto pr-1">
        {sessions.map((session) => {
          const leftPct = getPercent(session.arrival_time);
          const rightPct = getPercent(session.departure_time);
          const widthPct = Math.max(2, rightPct - leftPct);
          const isSelected = selectedSessionId === session.session_id;

          return (
            <div
              key={session.session_id}
              onClick={() => onSelectSession?.(session.session_id)}
              className={cn(
                'group relative flex items-center h-8 rounded-lg cursor-pointer px-2 transition-all',
                isSelected
                  ? 'bg-[#172330] border border-[#20E3FF] shadow-[0_0_12px_rgba(32,227,255,0.2)]'
                  : 'bg-[#080D12] hover:bg-[#162330] border border-[#253441]'
              )}
            >
              <div className="w-24 shrink-0 flex items-center gap-1.5">
                <span className="text-xs font-mono font-bold text-[#EAF5FA]">
                  {session.charger_id}
                </span>
                <span className="text-[10px] font-mono text-[#20E3FF]">
                  {session.requested_energy_kwh} kWh
                </span>
              </div>

              <div className="relative flex-1 h-5 rounded bg-[#111A22] border border-[#253441]/50 overflow-hidden">
                {/* Visual block representing parking / charging duration */}
                <div
                  className={cn(
                    'absolute h-full rounded transition-all',
                    isSelected
                      ? 'bg-gradient-to-r from-[#20E3FF] to-[#00D6B3] shadow-md shadow-[#20E3FF]/30'
                      : 'bg-gradient-to-r from-[#20E3FF]/60 to-[#00D6B3]/60 group-hover:from-[#20E3FF] group-hover:to-[#00D6B3]'
                  )}
                  style={{ left: `${leftPct}%`, width: `${widthPct}%` }}
                >
                  <div className="h-full flex items-center justify-between px-1.5 text-[9px] font-mono text-[#080D12] font-bold truncate">
                    <span>{formatTime(session.arrival_time)}</span>
                    <span>{formatTime(session.departure_time)}</span>
                  </div>
                </div>

                {/* Current simulation time vertical marker */}
                {currentPercent !== null && (
                  <div
                    className="absolute top-0 bottom-0 w-0.5 bg-[#20E3FF] z-10 pointer-events-none shadow-[0_0_8px_#20E3FF]"
                    style={{ left: `${currentPercent}%` }}
                  />
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

