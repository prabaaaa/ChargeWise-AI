import { useState, useEffect, useCallback, useRef } from 'react';
import {
  SimulationResult,
  ComparisonResult,
  ActiveSession,
  ChargingSession,
  CutoffEvent,
} from '../api/types';
import { apiClient } from '../api/client';
import { DEFAULT_SITE_CAP_KW } from '../utils/constants';

export function useSimulation() {
  const [isRunning, setIsRunning] = useState(false);
  const [speed, setSpeed] = useState<number>(1);
  const [siteCapKw, setSiteCapKw] = useState<number>(DEFAULT_SITE_CAP_KW);
  const [policy, setPolicy] = useState<'optimized' | 'uncontrolled'>('optimized');
  const [currentIntervalIndex, setCurrentIntervalIndex] = useState(0);
  const [selectedSessionId, setSelectedSessionId] = useState<string | null>(null);
  const [emergencySessions, setEmergencySessions] = useState<Set<string>>(new Set());
  const [leavingSoonSessions, setLeavingSoonSessions] = useState<Set<string>>(new Set());
  const [stoppedSessions, setStoppedSessions] = useState<Set<string>>(new Set());
  const [manualCutoffEvents, setManualCutoffEvents] = useState<CutoffEvent[]>([]);

  const [simulationResult, setSimulationResult] = useState<SimulationResult | null>(null);
  const [comparisonResult, setComparisonResult] = useState<ComparisonResult | null>(null);
  const [allSessions, setAllSessions] = useState<ChargingSession[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load simulation data & comparison
  const loadData = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const [sessions, simRes, compRes] = await Promise.all([
        apiClient.getSessions(),
        apiClient.runSimulation(policy, siteCapKw),
        apiClient.getComparison(siteCapKw),
      ]);
      setAllSessions(sessions);
      setSimulationResult(simRes);
      setComparisonResult(compRes);

      // Auto-advance to first interval with connected vehicles
      if (simRes?.intervals?.length) {
        const firstOccupied = simRes.intervals.findIndex(
          (iv) => iv.connected_vehicles && iv.connected_vehicles.length > 0
        );
        if (firstOccupied >= 0) {
          setCurrentIntervalIndex(firstOccupied);
        }
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to load simulation data');
    } finally {
      setIsLoading(false);
    }
  }, [policy, siteCapKw]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const totalIntervals = simulationResult?.intervals.length || 65;
  const currentInterval = simulationResult?.intervals[currentIntervalIndex] || null;
  const currentTime = currentInterval?.timestamp || '2026-10-21T09:00:00Z';

  // Compute active sessions at current interval
  const activeSessions: ActiveSession[] = (simulationResult?.intervals ? 
    (() => {
      if (!currentInterval) return [];
      const intervalAllocations = currentInterval.allocations || {};
      const activeIds = currentInterval.connected_vehicles || [];

      return activeIds.map((id) => {
        const sessionMeta = allSessions.find((s) => s.session_id === id);
        const outcome = simulationResult.outcomes.find((o) => o.session_id === id);
        const isEmergency = emergencySessions.has(id);
        const isLeavingSoon = leavingSoonSessions.has(id);
        const isStopped = stoppedSessions.has(id);

        let reqEnergy = sessionMeta?.requested_energy_kwh || 25;
        let effectiveTarget = sessionMeta?.effective_energy_target_kwh || reqEnergy;

        // Battery safety headroom
        if (sessionMeta?.battery_capacity_kwh && sessionMeta.initial_soc_percent !== null && sessionMeta.initial_soc_percent !== undefined) {
          const headroom = (sessionMeta.battery_capacity_kwh * (100 - sessionMeta.initial_soc_percent)) / 100;
          effectiveTarget = Math.min(effectiveTarget, headroom);
        }

        // Approximate energy delivered up to this interval
        let deliveredSoFar = 0;
        for (let i = 0; i <= currentIntervalIndex; i++) {
          const stepAlloc = simulationResult.intervals[i]?.allocations[id] || 0;
          deliveredSoFar += stepAlloc * 0.25;
        }

        const remainingKwh = Math.max(0, effectiveTarget - deliveredSoFar);
        const feasibility = outcome?.feasibility_status || (remainingKwh < 2 ? 'feasible' : 'at_risk');

        // Automatic Cutoff status evaluation
        let cutoffStatus = 'QUEUED';
        let allocatedKw = intervalAllocations[id] || (isEmergency ? 11.0 : 0);

        if (isStopped) {
          cutoffStatus = 'AUTO CUTOFF';
          allocatedKw = 0.0;
        } else if (remainingKwh <= 0.05 || deliveredSoFar >= effectiveTarget - 0.05) {
          cutoffStatus = 'TARGET REACHED';
          allocatedKw = 0.0;
        } else if (allocatedKw > 0.05) {
          cutoffStatus = 'CHARGING';
        } else {
          cutoffStatus = 'QUEUED';
        }

        // Priority score (0-100)
        let priority = 50;
        if (isEmergency) priority = 99;
        else if (isLeavingSoon) priority = 88;
        else if (cutoffStatus === 'TARGET REACHED' || isStopped) priority = 0;
        else priority = Math.min(95, Math.round((1 - (deliveredSoFar / effectiveTarget)) * 80 + 10));

        return {
          session_id: id,
          charger_id: sessionMeta?.charger_id || `CP-${id.replace(/\D+/g, '').padStart(2, '0')}`,
          arrival_time: sessionMeta?.arrival_time || currentInterval.timestamp,
          departure_time: isLeavingSoon ? '2026-10-21T10:30:00Z' : (sessionMeta?.departure_time || '2026-10-21T17:00:00Z'),
          energy_delivered_kwh: Math.round(deliveredSoFar * 10) / 10,
          energy_requested_kwh: sessionMeta?.requested_energy_kwh ?? reqEnergy,
          allocated_power_kw: allocatedKw,
          priority_score: priority,
          feasibility_status: feasibility,
          remaining_energy_kwh: Math.round(remainingKwh * 10) / 10,
          departure_source: sessionMeta?.departure_source || 'scheduled',
          is_emergency: isEmergency,
          is_manually_stopped: isStopped,
          cutoff_status: cutoffStatus,
          target_soc_percent: sessionMeta?.target_soc_percent ?? 85,
          effective_energy_target_kwh: Math.round(effectiveTarget * 10) / 10,
          initial_soc_percent: sessionMeta?.initial_soc_percent ?? 25,
          battery_capacity_kwh: sessionMeta?.battery_capacity_kwh ?? 70,
        };
      });
    })() : []);

  // Timer interval for playback
  const isRunningRef = useRef(isRunning);
  isRunningRef.current = isRunning;
  const speedRef = useRef(speed);
  speedRef.current = speed;

  const stepForward = useCallback(() => {
    setCurrentIntervalIndex((prev) => {
      if (prev >= totalIntervals - 1) {
        setIsRunning(false);
        return 0; // loop or stop
      }
      return prev + 1;
    });
  }, [totalIntervals]);

  useEffect(() => {
    if (!isRunning) return;
    const intervalMs = 1000 / speed;
    const intervalId = setInterval(() => {
      stepForward();
    }, intervalMs);
    return () => clearInterval(intervalId);
  }, [isRunning, speed, stepForward]);

  const togglePlayPause = () => {
    setIsRunning((prev) => !prev);
  };

  const reset = () => {
    setIsRunning(false);
    setCurrentIntervalIndex(0);
  };

  const declareEmergency = (sessionId: string) => {
    setEmergencySessions((prev) => {
      const next = new Set(prev);
      if (next.has(sessionId)) next.delete(sessionId);
      else next.add(sessionId);
      return next;
    });
  };

  const declareLeavingSoon = (sessionId: string) => {
    setLeavingSoonSessions((prev) => {
      const next = new Set(prev);
      if (next.has(sessionId)) next.delete(sessionId);
      else next.add(sessionId);
      return next;
    });
  };

  const stopCharging = async (sessionId: string) => {
    setStoppedSessions((prev) => new Set(prev).add(sessionId));
    const sessionMeta = allSessions.find((s) => s.session_id === sessionId);
    const manualEvt: CutoffEvent = {
      session_id: sessionId,
      charger_id: sessionMeta?.charger_id || `CP-${sessionId.replace(/\D+/g, '').padStart(2, '0')}`,
      timestamp: currentTime,
      reason: 'MANUAL_STOP',
      final_energy_delivered_kwh: activeSessions.find((s) => s.session_id === sessionId)?.energy_delivered_kwh || 0,
      target_energy_kwh: sessionMeta?.requested_energy_kwh || 25,
      target_achieved: false,
      final_soc_percent: activeSessions.find((s) => s.session_id === sessionId)?.initial_soc_percent ?? null,
      message: `Manual charging cutoff triggered by operator for ${sessionMeta?.charger_id || sessionId}. Power set to 0.0 kW immediately.`,
    };
    setManualCutoffEvents((prev) => [manualEvt, ...prev]);
    await apiClient.stopCharging(sessionId);
  };

  const startCharging = async (sessionId: string) => {
    setStoppedSessions((prev) => {
      const next = new Set(prev);
      next.delete(sessionId);
      return next;
    });
    await apiClient.startCharging(sessionId);
  };

  // Collect all cutoff events up to the current interval plus manual stops
  const allCutoffEvents: CutoffEvent[] = (() => {
    const events: CutoffEvent[] = [...manualCutoffEvents];
    if (simulationResult?.cutoff_events) {
      for (const ev of simulationResult.cutoff_events) {
        if (!events.some((e) => e.session_id === ev.session_id && e.reason === ev.reason)) {
          events.push(ev);
        }
      }
    }
    return events;
  })();

  return {
    isRunning,
    speed,
    siteCapKw,
    policy,
    currentIntervalIndex,
    totalIntervals,
    currentInterval,
    currentTime,
    activeSessions,
    allSessions,
    simulationResult,
    comparisonResult,
    selectedSessionId,
    stoppedSessions,
    cutoffEvents: allCutoffEvents,
    isLoading,
    error,
    togglePlayPause,
    stepForward,
    reset,
    setSpeed,
    setSiteCapKw,
    setPolicy,
    setSelectedSessionId,
    setCurrentIntervalIndex,
    declareEmergency,
    declareLeavingSoon,
    stopCharging,
    startCharging,
    reload: loadData,
  };
}
